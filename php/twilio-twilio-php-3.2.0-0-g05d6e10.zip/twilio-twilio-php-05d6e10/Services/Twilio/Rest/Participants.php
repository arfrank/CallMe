<?php

class Services_Twilio_Rest_Participants
    extends Services_Twilio_ListResource
{
}
